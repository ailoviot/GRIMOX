# grimox-qa

> QA visual autónomo para proyectos Grimox. Universal: funciona con cualquier LLM/IDE vía npm scripts.

## Qué es

Un CLI que prueba tu app web automáticamente en browser real (Playwright) tras cada `npm run build`. **Determinístico**: corre como parte del pipeline de npm, no depende de que el LLM "se acuerde" de ejecutarlo.

Análogo a **ESLint** o **TypeScript check**: si falla, el build falla. Si el build falla, nadie puede reportar "funcionando".

## Por qué existe

Las skills de Claude Code (y equivalentes en otros IDEs) son **declarativas** — sugieren al LLM qué hacer. El LLM puede ignorar sugerencias. En la práctica, los LLMs tienden a reportar "build pasó, listo" sin haber verificado visualmente.

**`grimox-qa` mueve el QA del LLM al pipeline.** No es "sugerencia que el LLM puede saltar", es "comando npm que se ejecuta siempre".

## Instalación

Proyectos nuevos scaffoldeados con `grimox create` ya vienen con `grimox-qa` configurado (feature `qa-cli` habilitado por defecto para stacks con UI).

Para agregar a un proyecto existente:

```bash
npm install --save-dev grimox-qa concurrently wait-on
```

Y agrega a tu `package.json`:

```json
{
  "scripts": {
    "build": "...",
    "postbuild": "grimox-qa --headless",
    "qa": "grimox-qa",
    "dev:qa": "concurrently \"npm run dev\" \"wait-on http://localhost:3000 && grimox-qa --headed --no-auto-close\""
  }
}
```

La primera ejecución descarga Chromium (~180MB, 1-2 min).

## Uso

```bash
npm run build        # build + QA headless automático
npm run qa           # QA manual con browser VISIBLE
npm run dev:qa       # dev server + QA watch en paralelo
```

Directamente:

```bash
npx grimox-qa --help
npx grimox-qa --headed
npx grimox-qa --plan custom.yml --url http://localhost:4000
```

## Configuración

`.grimox/qa-plan.yml`:

```yaml
version: 1
baseUrl: http://localhost:3000
autoDiscover: true  # descubre rutas del proyecto → smoke tests automáticos

# Credenciales (opcional — para flows con auth)
auth:
  testUser:
    email: demo@test.local
    password: demo12345
  loginUrl: /login
  fields:
    email: '#email'
    password: '#password'
    submit: 'button[type=submit]'
  redirectTo: /dashboard

# Flows específicos por feature
flows:
  - name: "Home loads"
    url: /
    steps:
      - assert: { text_visible: "Bienvenido" }

  - name: "Login exitoso"
    steps:
      - login: { as: demo }  # macro — usa config.auth
      - assert: { url_contains: /dashboard }

  - name: "Crear tarea"
    steps:
      - login: { as: demo }
      - goto: /tasks/new
      - fill: { selector: '#title', value: 'QA test' }
      - click: 'button[type=submit]'
      - assert: { text_visible: 'QA test' }
```

## Tipos de step soportados

| Step | Ejemplo | Qué hace |
|---|---|---|
| `goto` | `goto: /login` | Navega a URL (relativa a baseUrl) |
| `click` | `click: '#submit'` | Click en selector |
| `fill` | `fill: { selector: '#email', value: 'x' }` | Llena input |
| `login` | `login: { as: demo }` | Macro: login usando config.auth |
| `wait` | `wait: 500` | Delay explícito en ms |
| `assert.text_visible` | `assert: { text_visible: 'Hola' }` | Texto presente en página |
| `assert.element_visible` | `assert: { element_visible: 'h1' }` | Selector visible |
| `assert.url_contains` | `assert: { url_contains: /dashboard }` | URL actual contiene string |
| `assert.redirect_to` | `assert: { redirect_to: /login }` | Espera redirect a path |

## Modo headed vs headless

Auto-detectado por defecto:

| Entorno | Modo por defecto |
|---|---|
| Desktop local (Windows/Mac/Linux con DISPLAY) | **headed** (visible) |
| CI (GitHub Actions, Jenkins, etc.) | **headless** |
| Linux/WSL sin DISPLAY | **headless** + screenshots |
| SSH remoto | **headless** + screenshots |

Override manual:

```bash
grimox-qa --headed             # forzar visible
grimox-qa --headless           # forzar sin ventana
GRIMOX_QA_HEADLESS=1 grimox-qa # via env var
```

### En modo headed: browser por flow (UX dinámica)

En desktop local, cada flow abre **su propia ventana de Chrome** y la cierra al terminar. Esto da feedback visual claro (el usuario ve la ventana aparecer, ejecutar el test, cerrarse, y aparecer otra para el siguiente flow). Smoke tests comparten browser para no ralentizar.

En CI/headless, browser compartido para todos los flows → más rápido.

## Animaciones visuales

En modo headed, grimox-qa inyecta overlays animados en la página durante el test para hacer visualmente obvio qué está pasando:

- **Banner superior** con gradient animado mostrando flow actual y step en curso
- **Highlight del elemento** (outline cyan pulsing) antes de cada click/fill
- **Progress bar inferior** con % de flows completados
- **Flash final** (verde/rojo) al terminar el flow

Los overlays son CSS+DOM inyectados solo durante el test — la app real no los modifica. Al cerrar la página, desaparecen.

### Niveles de animación

```bash
grimox-qa --animations=full      # todo activo (default en desktop)
grimox-qa --animations=minimal   # solo banner superior
grimox-qa --animations=off       # sin overlays (default en headless/CI)
```

Configurable también en `.grimox/config.yml`:
```yaml
animations: minimal
```

### Cómo se ve durante un test

```
[0ms]    Banner aparece: "🧪 grimox-qa · Flow 1/7 — Login exitoso · init"
[200ms]  Input #email se resalta con outline cyan pulsing
[400ms]  Texto se escribe en el input
[800ms]  Banner: "Flow 1/7 — Login exitoso · fill #password"
[1200ms] Input #password se resalta y se llena
[1500ms] Botón submit halo amarillo pulsing
[1600ms] Click
[2500ms] Flash verde ✓ fullscreen
[3000ms] Browser se cierra, próximo flow abre nueva ventana
```

## Exit codes

| Código | Significado |
|---|---|
| `0` | Todos los flows pasaron |
| `1` | Al menos un flow falló |
| `2` | **Escalación**: mismo flow falló 3 veces seguidas. Requiere intervención manual. Reset con `grimox-qa --reset`. |

## Evidencia de fallos

Screenshots automáticos en `.grimox/qa-evidence/`:

- `smoke-<path>.png` — rutas que fallaron auto-discovery
- `flow-<name>-step<N>-attempt<M>.png` — step exacto donde falló el flow

## Auto-discovery

Detecta rutas de:

- **Next.js App Router** (`app/` o `src/app/`)
- **Next.js Pages Router** (`pages/` o `src/pages/`)
- **Nuxt** (`pages/`)
- **SvelteKit** (`src/routes/`)

Crea un smoke test por ruta: navega, espera status 2xx/3xx, verifica sin console errors.

## Universal entre IDEs

Funciona idéntico en:

- ✅ Claude Code CLI y extensión VSCode
- ✅ OpenCode
- ✅ Cursor (agent mode)
- ✅ Windsurf (Cascade)
- ✅ Antigravity
- ✅ Trae
- ✅ GitHub Copilot (agent mode)

Porque es un comando npm — no depende de APIs de IDEs particulares.

## Tamaño y deps

- Paquete: ~15KB
- Runtime dep: `playwright` (tras `npm install`, ~180MB con Chromium)
- Parseo: `yaml`, `picocolors`

## Licencia

MIT
